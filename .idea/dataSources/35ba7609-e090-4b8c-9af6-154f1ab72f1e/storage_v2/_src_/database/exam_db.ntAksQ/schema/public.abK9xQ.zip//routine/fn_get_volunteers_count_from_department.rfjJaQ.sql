create function fn_get_volunteers_count_from_department(searched_volunteers_department character varying) returns integer
    language plpgsql
as
$$
    DECLARE result INT;
    BEGIN
        SELECT
            COUNT(*)
        FROM
            volunteers AS v
        JOIN
            volunteers_departments AS vd ON v.department_id = vd.id
        WHERE
            vd.department_name = searched_volunteers_department
        GROUP BY
            vd.department_name
        INTO result;
    RETURN result;
    END;
$$;

alter function fn_get_volunteers_count_from_department(varchar) owner to postgres;

