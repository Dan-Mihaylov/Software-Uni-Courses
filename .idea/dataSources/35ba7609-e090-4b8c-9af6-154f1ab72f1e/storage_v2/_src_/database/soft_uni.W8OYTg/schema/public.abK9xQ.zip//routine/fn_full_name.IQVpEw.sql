create function fn_full_name(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
    DECLARE result VARCHAR;
    BEGIN
        result := CONCAT(INITCAP(first_name), ' ', INITCAP(last_name));
        RETURN result;
    END;
$$;

alter function fn_full_name(varchar, varchar) owner to postgres;

