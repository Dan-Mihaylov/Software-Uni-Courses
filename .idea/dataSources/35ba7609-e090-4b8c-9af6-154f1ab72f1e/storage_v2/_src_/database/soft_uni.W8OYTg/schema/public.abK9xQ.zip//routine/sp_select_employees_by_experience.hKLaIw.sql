create procedure sp_select_employees_by_experience(IN minimum_years integer)
    language plpgsql
as
$$
    DECLARE employee_count INT;

    BEGIN
       SELECT
           COUNT(employee_id) INTO employee_count
        FROM
            employees
        WHERE date_part('year', AGE(now(), hire_date)) > minimum_years;
       RAISE NOTICE '%', employee_count;
    END;
    $$;

alter procedure sp_select_employees_by_experience(integer) owner to postgres;

