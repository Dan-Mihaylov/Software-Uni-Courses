create function fn_count_employees_by_town(town_name character varying) returns integer
    language plpgsql
as
$$
    DECLARE employee_count INT;
    BEGIN
        SELECT COUNT(*)
        FROM employees AS e
        JOIN addresses AS a USING (address_id)
        JOIN towns AS t USING (town_id)
        WHERE t.name = town_name
        INTO employee_count;
        RETURN employee_count;
    END;
$$;

alter function fn_count_employees_by_town(varchar) owner to postgres;

