create function trigger_deleted_employees_function() returns trigger
    language plpgsql
as
$$
    BEGIN
        INSERT INTO deleted_employees (first_name, last_name, middle_name, job_title, salary)
        VALUES(OLD.first_name, OLD.last_name, OLD.middle_name, OLD.job_title, OLD.salary);
    RETURN NEW;
    END;
$$;

alter function trigger_deleted_employees_function() owner to postgres;

