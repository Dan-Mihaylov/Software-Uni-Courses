create function fn_courses_by_client(phone_num character varying) returns integer
    language plpgsql
as
$$
    DECLARE total INT;
    BEGIN
        SELECT
            COUNT(co.id)
        FROM
            clients AS c
        JOIN
            courses AS co ON co.client_id = c.id
        WHERE
            c.phone_number = phone_num
        INTO total;
        RETURN total;
    END;

$$;

alter function fn_courses_by_client(varchar) owner to postgres;

