create procedure sp_courses_by_address(IN address_name character varying)
    language plpgsql
as
$$
BEGIN
    TRUNCATE TABLE search_results;
    INSERT INTO search_results (address_name, full_name, level_of_bill, make, condition, category_name)
       (SELECT
            a.name,
            cl.full_name,
            CASE
                WHEN co.bill <= 20 THEN 'Low'
                WHEN co.bill <= 30 THEN 'Medium'
                ELSE 'High'
            END,
            ca.make,
            ca.condition,
            cat.name
    FROM
        addresses AS a
    JOIN
        courses AS co ON co.from_address_id = a.id
    JOIN
        clients AS cl ON co.client_id = cl.id
    JOIN
        cars AS ca ON co.car_id = ca.id
    JOIN
        categories AS cat ON cat.id = ca.category_id
    WHERE
        a.name = address_name
    ORDER BY
        ca.make,
        cl.full_name);
END
$$;

alter procedure sp_courses_by_address(varchar) owner to postgres;

