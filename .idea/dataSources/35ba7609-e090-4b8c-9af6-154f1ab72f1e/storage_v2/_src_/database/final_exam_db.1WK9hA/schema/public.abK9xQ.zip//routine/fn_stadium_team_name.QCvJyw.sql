create function fn_stadium_team_name(stadium_name character varying)
    returns TABLE(name character varying)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT
            t.name
        FROM
            teams AS t
        JOIN
            stadiums AS s ON s.id = t.stadium_id
        WHERE
            s.name = stadium_name
        ORDER BY t.name
    ;
    RETURN;
    END;
$$;

alter function fn_stadium_team_name(varchar) owner to postgres;

