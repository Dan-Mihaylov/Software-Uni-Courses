create function is_word_comprised(set_of_letters character varying, word character varying) returns boolean
    language plpgsql
as
$$
    BEGIN
       RETURN TRIM(LOWER(set_of_letters), LOWER(word)) = '';
    END;


$$;

alter function is_word_comprised(varchar, varchar) owner to postgres;

