create procedure sp_withdraw_money(IN account_id integer, IN money_amount numeric)
    language plpgsql
as
$$
    BEGIN
        IF (SELECT balance FROM accounts WHERE id = account_id) < money_amount THEN RAISE NOTICE 'Insufficient balance to withdraw %', money_amount;
        ELSE
        UPDATE accounts
            SET balance = balance - money_amount
            WHERE id = account_id;
        END IF;
        RETURN;
    END;
$$;

alter procedure sp_withdraw_money(integer, numeric) owner to postgres;

