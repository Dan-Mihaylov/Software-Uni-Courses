create function fn_calculate_future_value(initial_sum double precision, yearly_interest_rate double precision, number_of_years integer) returns numeric
    language plpgsql
as
$$
    DECLARE result NUMERIC;
    BEGIN
        result := initial_sum * (POWER(1 + yearly_interest_rate, number_of_years));
        result := TRUNC(result, 4);
        RETURN result;
    END;
$$;

alter function fn_calculate_future_value(double precision, double precision, integer) owner to postgres;

