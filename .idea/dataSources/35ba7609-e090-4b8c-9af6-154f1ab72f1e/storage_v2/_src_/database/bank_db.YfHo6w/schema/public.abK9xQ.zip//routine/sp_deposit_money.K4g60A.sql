create procedure sp_deposit_money(IN account_id integer, IN money_amount numeric)
    language plpgsql
as
$$
    DECLARE compare_balance NUMERIC;

    BEGIN
        UPDATE accounts
        SET balance = balance + money_amount
        WHERE id = account_id;
        RETURN ;
    END;
$$;

alter procedure sp_deposit_money(integer, numeric) owner to postgres;

