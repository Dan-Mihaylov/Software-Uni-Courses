create procedure sp_deposit_money(IN account_id integer, IN money_amount numeric)
    language plpgsql
as
$$
    DECLARE compare_balance NUMERIC;

    BEGIN
        compare_balance := (SELECT balance FROM accounts WHERE id = account_id) + money_amount;
        UPDATE accounts
        SET balance = balance + money_amount
        WHERE id = account_id;
        IF (SELECT balance FROM accounts WHERE id = account_id) != compare_balance THEN ROLLBACK;
        ELSE COMMIT;
        RETURN ;
        END IF;
    END;
$$;

alter procedure sp_deposit_money(integer, numeric) owner to postgres;

