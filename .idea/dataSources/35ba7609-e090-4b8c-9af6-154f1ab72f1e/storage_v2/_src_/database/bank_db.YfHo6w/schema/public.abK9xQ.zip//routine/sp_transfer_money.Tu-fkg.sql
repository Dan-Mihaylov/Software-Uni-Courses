create procedure sp_transfer_money(IN sender_id integer, IN receiver_id integer, IN amount numeric)
    language plpgsql
as
$$
    DECLARE sender_initial_balance NUMERIC;
            receiver_initial_balance NUMERIC;
    BEGIN
        sender_initial_balance := (SELECT balance FROM accounts WHERE id = sender_id);
        receiver_initial_balance := (SELECT balance FROM accounts WHERE id = receiver_id);

        CALL sp_withdraw_money(sender_id, amount);
        CALL sp_deposit_money(receiver_id, amount);

        IF sender_initial_balance = (SELECT balance FROM accounts WHERE id = sender_id)
            OR
           receiver_initial_balance = (SELECT balance FROM accounts WHERE id = receiver_id)
            THEN ROLLBACK ;
        ELSE
            COMMIT;
        END IF;
    END;
$$;

alter procedure sp_transfer_money(integer, integer, numeric) owner to postgres;

