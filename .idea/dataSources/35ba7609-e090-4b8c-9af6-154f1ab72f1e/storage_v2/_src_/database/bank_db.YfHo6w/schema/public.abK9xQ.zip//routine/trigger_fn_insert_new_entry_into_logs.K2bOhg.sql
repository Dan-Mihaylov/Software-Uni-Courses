create function trigger_fn_insert_new_entry_into_logs() returns trigger
    language plpgsql
as
$$
    BEGIN
        INSERT INTO logs(account_id, old_sum, new_sum)
        VALUES (OLD.id, OLD.balance, NEW.balance);
        RETURN NULL;
    END;
$$;

alter function trigger_fn_insert_new_entry_into_logs() owner to postgres;

