create function fn_creator_with_board_games(name character varying) returns integer
    language plpgsql
as
$$
    DECLARE total_games INT;
    BEGIN
        SELECT
            COUNT(cbg.board_game_id) AS total
        FROM
            creators AS c
        JOIN
            creators_board_games AS cbg ON cbg.creator_id = c.id
        WHERE
            c.first_name = name
        INTO total_games;
    RETURN total_games;
    END;
$$;

alter function fn_creator_with_board_games(varchar) owner to postgres;

