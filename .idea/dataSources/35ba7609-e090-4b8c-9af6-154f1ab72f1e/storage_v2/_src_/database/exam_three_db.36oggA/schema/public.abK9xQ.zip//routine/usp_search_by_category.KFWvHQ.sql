create procedure usp_search_by_category(IN category character varying)
    language plpgsql
as
$$
    BEGIN
        TRUNCATE TABLE search_results;

        INSERT INTO search_results (name, release_year, rating, category_name, publisher_name, min_players, max_players)
        (SELECT
            bg.name,
            bg.release_year,
            bg.rating,
            c.name,
            p.name,
            CONCAT(pr.min_players::VARCHAR, ' ', 'people'),
            CONCAT(pr.max_players::VARCHAR, ' ', 'people')
        FROM
            board_games AS bg
        JOIN
            categories AS c ON c.id = bg.category_id
        JOIN
            players_ranges AS pr ON pr.id = bg.players_range_id
        JOIN
            publishers AS p ON p.id = bg.publisher_id
        WHERE c.name = category
        ORDER BY
            p.name ASC,
            bg.release_year DESC
        );
    END;
$$;

alter procedure usp_search_by_category(varchar) owner to postgres;

