create function fn_difficulty_level(level integer) returns character varying
    language plpgsql
as
$$
    DECLARE result VARCHAR;
    BEGIN
        IF level <= 40 THEN result:= 'Normal Difficulty';
        ELSIF level BETWEEN 41 AND 60 THEN result := 'Nightmare Difficulty';
        ELSIF level > 60 THEN result := 'Hell Difficulty';
        END IF;
        RETURN result;
    END;
$$;

alter function fn_difficulty_level(integer) owner to postgres;

