create view curr_view(id, currency_code, substring) as
SELECT currencies.id,
       currencies.currency_code,
       SUBSTRING(currencies.description FROM 5) AS "substring"
FROM currencies;

alter table curr_view
    owner to postgres;

