create view view_continents_countries_currencies_details("Continent Details", "Country Information", "Currencies") as
SELECT concat(c1.continent_name, ': ', c1.continent_code)                           AS "Continent Details",
       concat_ws(' - '::text, c2.country_name, c2.capital, c2.area_in_sq_km, 'km2') AS "Country Information",
       concat(c3.description, ' (', c3.currency_code, ')')                          AS "Currencies"
FROM continents c1
         JOIN countries c2 ON c1.continent_code = c2.continent_code
         JOIN currencies c3 ON c2.currency_code = c3.currency_code
ORDER BY (concat_ws(' - '::text, c2.country_name, c2.capital, c2.area_in_sq_km, 'km2')),
         (concat(c3.description, ' (', c3.currency_code, ')'));

alter table view_continents_countries_currencies_details
    owner to postgres;

