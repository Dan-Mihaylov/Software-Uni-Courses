create view view_new_view(salary) as
SELECT to_char(view_performance_rating.salary, '99999999.99'::text) AS salary
FROM view_performance_rating;

alter table view_new_view
    owner to postgres;

